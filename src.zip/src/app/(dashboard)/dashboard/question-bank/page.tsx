"use client";

import {
  QuestionCreateDialog,
  QuestionCreateFormData,
} from "@/components/form-builder/question-create-dialog";
import { Header } from "@/components/layout/header";
import { ApiError } from "@/lib/api";
import { questionBankService } from "@/services/question-bank.service";
import { QuestionType, type QuestionDefinition } from "@/types/question-bank";
import { useMutation, useQuery } from "@tanstack/react-query";
import {
  Archive,
  ChevronRight,
  Copy,
  Loader2,
  MoreVertical,
  Pencil,
  Plus,
  RefreshCw,
  Search,
  Settings2,
} from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";

export default function QuestionBankPage() {
  const [includeArchived, setIncludeArchived] = useState(false);

  const [searchQuery, setSearchQuery] = useState("");

  const [openMenuId, setOpenMenuId] = useState<number | null>(null);

  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);

  const { data, isLoading, isFetching, error, refetch } = useQuery({
    queryKey: ["question-bank", includeArchived],

    queryFn: async () => {
      const response = await questionBankService.list(includeArchived);

      return response.data;
    },
  });

  const items = useMemo(() => data?.items ?? [], [data?.items]);

  const filteredItems = useMemo(() => {
    const query = searchQuery.trim().toLocaleLowerCase();

    if (!query) {
      return items;
    }

    return items.filter(
      (item) =>
        item.name.toLocaleLowerCase().includes(query) ||
        item.code.toLocaleLowerCase().includes(query),
    );
  }, [items, searchQuery]);

  const createMutation = useMutation({
    mutationFn: async (formData: QuestionCreateFormData) => {
      return questionBankService.create({
        definition: {
          code: formData.code,
          name: formData.name,
          description: formData.description.trim()
            ? formData.description.trim()
            : null,
        },

        version: {
          label: formData.label,
          help_text: formData.helpText.trim() ? formData.helpText.trim() : null,
          question_type: formData.questionType,
          base_config: {},
          options: formData.options.map((option, index) => ({
            value: option.value.trim(),
            label: option.label.trim(),
            position: index,
            option_metadata: {},
          })),
        },
      });
    },

    onSuccess: async () => {
      setIsCreateDialogOpen(false);

      await refetch();

      toast.success("Question créée avec succès.");
    },

    onError: (error) => {
      const message =
        error instanceof ApiError
          ? error.message
          : error instanceof Error
            ? error.message
            : "Impossible de créer la question.";

      toast.error(message);
    },
  });

  return (
    <>
      <Header
        title="Banque de questions"
        description="Centralisez les questions réutilisables de vos formulaires."
        actions={
          <>
            <button
              type="button"
              onClick={() => {
                setIsCreateDialogOpen(true);
              }}
              style={{
                height: "36px",
                padding: "0 0.875rem",
                borderRadius: "0.625rem",
                border: "1px solid rgba(93, 184, 58, 0.25)",
                background: "rgba(93, 184, 58, 0.1)",
                color: "#5DB83A",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: "0.5rem",
                fontSize: "0.8125rem",
                fontWeight: 600,
                cursor: "pointer",
              }}
            >
              <Plus size={16} />
              Nouvelle question
            </button>

            <button
              type="button"
              onClick={() => {
                void refetch();
              }}
              disabled={isFetching}
              style={{
                width: "36px",
                height: "36px",
                borderRadius: "0.625rem",
                border: "1px solid var(--color-border)",
                background: "var(--color-surface-raised)",
                color: "var(--color-foreground-muted)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                cursor: isFetching ? "not-allowed" : "pointer",
                opacity: isFetching ? 0.6 : 1,
              }}
              title="Actualiser"
            >
              {isFetching ? (
                <Loader2 size={16} className="animate-spin" />
              ) : (
                <RefreshCw size={16} />
              )}
            </button>
          </>
        }
      />

      <div
        style={{
          flex: 1,
          overflow: "auto",
          padding: "1.5rem",
        }}
      >
        <div
          style={{
            border: "1px solid var(--color-border)",
            borderRadius: "1rem",
            background: "var(--color-surface)",
          }}
        >
          {/* Barre de contrôle */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "0.75rem",
              padding: "1rem 1.25rem",
              borderBottom: "1px solid var(--color-border)",
            }}
          >
            <div
              style={{
                position: "relative",
                flex: 1,
                minWidth: 0,
              }}
            >
              <Search
                size={16}
                style={{
                  position: "absolute",
                  left: "0.75rem",
                  top: "50%",
                  transform: "translateY(-50%)",
                  color: "var(--color-foreground-muted)",
                  pointerEvents: "none",
                }}
              />

              <input
                type="search"
                value={searchQuery}
                onChange={(event) => {
                  setSearchQuery(event.target.value);
                }}
                placeholder="Rechercher une question..."
                onKeyDown={(event) => {
                  if (event.key === "Escape") {
                    setSearchQuery("");
                    event.currentTarget.blur();
                  }
                }}
                style={{
                  width: "100%",
                  height: "40px",
                  padding: "0 0.875rem 0 2.375rem",
                  borderRadius: "0.625rem",
                  border: "1px solid var(--color-border)",
                  background: "var(--color-surface-raised)",
                  color: "var(--color-foreground)",
                  outline: "none",
                  fontSize: "0.8125rem",
                  boxSizing: "border-box",
                }}
              />
            </div>

            <label
              style={{
                display: "flex",
                alignItems: "center",
                gap: "0.5rem",
                flexShrink: 0,
                fontSize: "0.75rem",
                color: "var(--color-foreground-muted)",
                cursor: "pointer",
              }}
            >
              <input
                type="checkbox"
                checked={includeArchived}
                onChange={(event) => {
                  setIncludeArchived(event.target.checked);
                  setOpenMenuId(null);
                }}
              />
              Afficher les archivées
            </label>
          </div>

          {/* Corps */}
          {isLoading ? (
            <div
              style={{
                minHeight: "320px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                color: "var(--color-foreground-muted)",
              }}
            >
              <Loader2 size={22} className="animate-spin" />
            </div>
          ) : error ? (
            <div
              style={{
                minHeight: "320px",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                gap: "0.75rem",
                padding: "2rem",
                textAlign: "center",
              }}
            >
              <div
                style={{
                  fontSize: "0.9375rem",
                  fontWeight: 600,
                  color: "var(--color-foreground)",
                }}
              >
                Impossible de charger la banque
              </div>

              <div
                style={{
                  fontSize: "0.8125rem",
                  color: "var(--color-foreground-muted)",
                  maxWidth: "520px",
                }}
              >
                {error instanceof ApiError
                  ? error.message
                  : error instanceof Error
                    ? error.message
                    : "Une erreur est survenue."}
              </div>

              <button
                type="button"
                onClick={() => {
                  void refetch();
                }}
                style={{
                  height: "36px",
                  padding: "0 0.875rem",
                  borderRadius: "0.625rem",
                  border: "1px solid var(--color-border)",
                  background: "var(--color-surface-raised)",
                  color: "var(--color-foreground)",
                  fontSize: "0.8125rem",
                  fontWeight: 600,
                  cursor: "pointer",
                }}
              >
                Réessayer
              </button>
            </div>
          ) : filteredItems.length === 0 ? (
            <div
              style={{
                minHeight: "320px",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                gap: "0.625rem",
                padding: "2rem",
                textAlign: "center",
              }}
            >
              <div
                style={{
                  width: "52px",
                  height: "52px",
                  borderRadius: "0.875rem",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  background: "var(--color-surface-raised)",
                  border: "1px solid var(--color-border)",
                }}
              >
                <Settings2 size={22} color="#5DB83A" />
              </div>

              <div
                style={{
                  fontSize: "0.9375rem",
                  fontWeight: 600,
                  color: "var(--color-foreground)",
                }}
              >
                {searchQuery
                  ? "Aucun résultat"
                  : "Votre banque de questions est vide"}
              </div>

              <div
                style={{
                  fontSize: "0.8125rem",
                  color: "var(--color-foreground-muted)",
                  maxWidth: "460px",
                }}
              >
                {searchQuery
                  ? `Aucune question ne correspond à « ${searchQuery} ».`
                  : "Créez votre première question pour commencer à construire vos formulaires."}
              </div>

              {searchQuery && (
                <button
                  type="button"
                  onClick={() => {
                    setSearchQuery("");
                  }}
                  style={{
                    marginTop: "0.25rem",
                    border: 0,
                    background: "transparent",
                    color: "#5DB83A",
                    fontSize: "0.75rem",
                    fontWeight: 600,
                    cursor: "pointer",
                  }}
                >
                  Effacer la recherche
                </button>
              )}
            </div>
          ) : (
            <div>
              {/* En-tête */}
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "minmax(280px, 1fr) 180px 120px 48px",
                  gap: "1rem",
                  padding: "0.75rem 1.25rem",
                  borderBottom: "1px solid var(--color-border)",
                  fontSize: "0.6875rem",
                  fontWeight: 700,
                  textTransform: "uppercase",
                  letterSpacing: "0.04em",
                  color: "var(--color-foreground-muted)",
                }}
              >
                <div>Question</div>
                <div>Type</div>
                <div>Statut</div>
                <div />
              </div>

              {filteredItems.map((item) => (
                <QuestionRow
                  key={item.id}
                  item={item}
                  menuOpen={openMenuId === item.id}
                  onToggleMenu={() => {
                    setOpenMenuId((current) =>
                      current === item.id ? null : item.id,
                    );
                  }}
                />
              ))}
            </div>
          )}
        </div>
      </div>

      {isCreateDialogOpen && (
        <QuestionCreateDialog
          isPending={createMutation.isPending}
          onClose={() => {
            if (!createMutation.isPending) {
              setIsCreateDialogOpen(false);
            }
          }}
          onSubmit={(formData) => {
            createMutation.mutate(formData);
          }}
        />
      )}
    </>
  );
}

function QuestionRow({
  item,
  menuOpen,
  onToggleMenu,
}: {
  item: QuestionDefinition;
  menuOpen: boolean;
  onToggleMenu: () => void;
}) {
  return (
    <div
      style={{
        position: "relative",
        display: "grid",
        gridTemplateColumns: "minmax(280px, 1fr) 180px 120px 48px",
        gap: "1rem",
        alignItems: "center",
        padding: "0.875rem 1.25rem",
        borderBottom: "1px solid var(--color-border)",
        transition: "background 0.15s ease",
      }}
      onMouseEnter={(event) => {
        event.currentTarget.style.background = "var(--color-surface-raised)";
      }}
      onMouseLeave={(event) => {
        event.currentTarget.style.background = "transparent";
      }}
    >
      <div
        style={{
          minWidth: 0,
          display: "flex",
          alignItems: "center",
          gap: "0.75rem",
        }}
      >
        <div
          style={{
            width: "38px",
            height: "38px",
            flexShrink: 0,
            borderRadius: "0.625rem",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            background: "rgba(93, 184, 58, 0.08)",
            border: "1px solid rgba(93, 184, 58, 0.15)",
            color: "#5DB83A",
          }}
        >
          <Settings2 size={17} />
        </div>

        <div
          style={{
            minWidth: 0,
          }}
        >
          <div
            style={{
              overflow: "hidden",
              textOverflow: "ellipsis",
              whiteSpace: "nowrap",
              fontSize: "0.875rem",
              fontWeight: 600,
              color: "var(--color-foreground)",
            }}
          >
            {item.name}
          </div>

          <div
            style={{
              marginTop: "0.125rem",
              fontSize: "0.6875rem",
              color: "var(--color-foreground-muted)",
            }}
          >
            {item.code}
          </div>
        </div>
      </div>

      <div
        style={{
          fontSize: "0.75rem",
          color: "var(--color-foreground-muted)",
        }}
      >
        {item.question_type ? getQuestionTypeLabel(item.question_type) : "—"}
      </div>

      <div>
        <span
          style={{
            display: "inline-flex",
            alignItems: "center",
            height: "24px",
            padding: "0 0.5rem",
            borderRadius: "999px",
            background:
              item.status === "ACTIVE"
                ? "rgba(93, 184, 58, 0.1)"
                : "rgba(148, 163, 184, 0.1)",
            color:
              item.status === "ACTIVE"
                ? "#5DB83A"
                : "var(--color-foreground-muted)",
            fontSize: "0.6875rem",
            fontWeight: 600,
          }}
        >
          {item.status === "ACTIVE" ? "Active" : "Archivée"}
        </span>
      </div>

      <div
        style={{
          position: "relative",
          display: "flex",
          justifyContent: "flex-end",
        }}
      >
        <button
          type="button"
          onClick={(event) => {
            event.stopPropagation();

            onToggleMenu();
          }}
          style={{
            width: "34px",
            height: "34px",
            borderRadius: "0.5rem",
            border: "1px solid transparent",
            background: menuOpen
              ? "var(--color-surface-raised)"
              : "transparent",
            color: "var(--color-foreground-muted)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            cursor: "pointer",
          }}
          aria-label={`Actions pour ${item.name}`}
        >
          <MoreVertical size={17} />
        </button>

        {menuOpen && <QuestionContextMenu />}
      </div>
    </div>
  );
}

function QuestionContextMenu() {
  return (
    <div
      style={{
        position: "absolute",
        top: "calc(100% + 0.375rem)",
        right: 0,
        zIndex: 100,
        minWidth: "190px",
        padding: "0.375rem",
        borderRadius: "0.75rem",
        border: "1px solid var(--color-border)",
        background: "var(--color-surface)",
        boxShadow: "0 12px 32px rgba(0, 0, 0, 0.14)",
      }}
    >
      <MenuButton icon={ChevronRight} label="Voir les détails" />

      <MenuButton icon={Pencil} label="Modifier" />

      <MenuButton icon={Copy} label="Dupliquer" />

      <div
        style={{
          height: "1px",
          margin: "0.375rem 0",
          background: "var(--color-border)",
        }}
      />

      <MenuButton icon={Archive} label="Archiver" />
    </div>
  );
}

function MenuButton({
  icon: Icon,
  label,
}: {
  icon: typeof Pencil;
  label: string;
}) {
  return (
    <button
      type="button"
      onClick={() => {
        toast.info("Cette action sera branchée à l'étape suivante.");
      }}
      style={{
        width: "100%",
        height: "36px",
        padding: "0 0.625rem",
        border: 0,
        borderRadius: "0.5rem",
        background: "transparent",
        color: "var(--color-foreground)",
        display: "flex",
        alignItems: "center",
        gap: "0.625rem",
        fontSize: "0.8125rem",
        fontWeight: 500,
        textAlign: "left",
        cursor: "pointer",
      }}
      onMouseEnter={(event) => {
        event.currentTarget.style.background = "var(--color-surface-raised)";
      }}
      onMouseLeave={(event) => {
        event.currentTarget.style.background = "transparent";
      }}
    >
      <Icon size={15} />
      {label}
    </button>
  );
}

function getQuestionTypeLabel(type: QuestionType): string {
  const labels: Record<QuestionType, string> = {
    TEXT: "Texte",
    LONG_TEXT: "Texte long",
    EMAIL: "E-mail",
    PHONE: "Téléphone",
    URL: "URL",
    ADDRESS: "Adresse",
    INTEGER: "Nombre entier",
    DECIMAL: "Nombre décimal",
    PERCENTAGE: "Pourcentage",
    CURRENCY: "Monnaie",
    SINGLE_CHOICE: "Choix unique",
    MULTIPLE_CHOICE: "Choix multiple",
    DROPDOWN: "Liste",
    AUTOCOMPLETE: "Recherche",
    RATING: "Évaluation",
    LIKERT_SCALE: "Échelle",
    RANKING: "Classement",
    DATE: "Date",
    TIME: "Heure",
    DATETIME: "Date + heure",
    DURATION: "Durée",
    POINT: "Point GPS",
    LINE: "Ligne",
    POLYGON: "Polygone",
    AREA: "Zone",
    PHOTO: "Photo",
    VIDEO: "Vidéo",
    AUDIO: "Audio",
    FILE: "Fichier",
    SIGNATURE: "Signature",
    QR_CODE: "QR Code",
    BARCODE: "Code-barres",
    ENTITY_SELECT: "Sélection d'entité",
    ENTITY_SEARCH: "Recherche d'entité",
    CALCULATION: "Calcul",
    NOTE: "Note",
    CONSENT: "Consentement",
    HIDDEN: "Champ caché",
  };

  return labels[type];
}
