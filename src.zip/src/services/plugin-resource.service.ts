import { api } from "@/lib/api";
import type { ApiResponse } from "@/types/common";
import type {
  PluginResource,
  PluginResourceCreate,
  PluginResourceFieldCreate,
  PluginResourceFieldUpdate,
  PluginResourceListResponse,
  PluginResourceUpdate,
} from "@/types/plugin-resource";

export const pluginResourceService = {
  async list(
    pluginId: number,
  ): Promise<ApiResponse<PluginResourceListResponse>> {
    return api.get<PluginResourceListResponse>(
      `/plugins/${pluginId}/resources`,
    );
  },

  async get(resourceId: number): Promise<ApiResponse<PluginResource>> {
    return api.get<PluginResource>(`/plugins/resources/${resourceId}`);
  },

  async create(
    pluginId: number,
    payload: PluginResourceCreate,
  ): Promise<ApiResponse<PluginResource>> {
    return api.post<PluginResource>(`/plugins/${pluginId}/resources`, payload);
  },

  async update(
    resourceId: number,
    payload: PluginResourceUpdate,
  ): Promise<ApiResponse<PluginResource>> {
    return api.patch<PluginResource>(
      `/plugins/resources/${resourceId}`,
      payload,
    );
  },

  async delete(resourceId: number): Promise<ApiResponse<null>> {
    return api.delete<null>(`/plugins/resources/${resourceId}`);
  },

  async addField(
    resourceId: number,
    payload: PluginResourceFieldCreate,
  ): Promise<ApiResponse<PluginResource>> {
    return api.post<PluginResource>(
      `/plugins/resources/${resourceId}/fields`,
      payload,
    );
  },

  async updateField(
    resourceId: number,
    fieldId: number,
    payload: PluginResourceFieldUpdate,
  ): Promise<ApiResponse<PluginResource>> {
    return api.patch<PluginResource>(
      `/plugins/resources/${resourceId}/fields/${fieldId}`,
      payload,
    );
  },

  async deleteField(
    resourceId: number,
    fieldId: number,
  ): Promise<ApiResponse<PluginResource>> {
    return api.delete<PluginResource>(
      `/plugins/resources/${resourceId}/fields/${fieldId}`,
    );
  },
};
