import { api } from "@/lib/api";
import type { ApiResponse } from "@/types/common";
import {
  QuestionCreateRequest,
  QuestionDefinition,
  QuestionDefinitionDetail,
  QuestionDefinitionListResponse,
} from "@/types/question-bank";

export const questionBankService = {
  async list(
    includeArchived = false,
  ): Promise<ApiResponse<QuestionDefinitionListResponse>> {
    const query = includeArchived ? "?include_archived=true" : "";

    return api.get<QuestionDefinitionListResponse>(`/question-bank/${query}`);
  },

  async get(
    questionId: number,
  ): Promise<ApiResponse<QuestionDefinitionDetail>> {
    return api.get<QuestionDefinitionDetail>(`/question-bank/${questionId}`);
  },

  async create(
    payload: QuestionCreateRequest,
  ): Promise<ApiResponse<QuestionDefinition>> {
    return api.post<QuestionDefinition>("/question-bank/", payload);
  },
};
